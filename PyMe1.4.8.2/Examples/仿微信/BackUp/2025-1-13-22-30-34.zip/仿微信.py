#coding=utf-8
#import libs 
import sys
import os
from   os.path import abspath, dirname
sys.path.insert(0,abspath(dirname(__file__)))
import 仿微信_cmd
import 仿微信_sty
import Fun
import EXUIControl
EXUIControl.FunLib = Fun
EXUIControl.G_ExeDir = Fun.G_ExeDir
EXUIControl.G_ResDir = Fun.G_ResDir
import tkinter
from   tkinter import *
import tkinter.ttk
import tkinter.font
from   PIL import Image,ImageTk

#Add your Varial Here: (Keep This Line of comments)
#Define UI Class
class  仿微信:
    def __init__(self,root,isTKroot = True,params=None):
        uiName = Fun.GetUIName(root,self.__class__.__name__)
        self.uiName = uiName
        Fun.Register(uiName,'UIClass',self)
        self.root = root
        self.isTKroot = isTKroot
        self.firstRun = True
        Fun.G_UIParamsDictionary[uiName]=params
        Fun.G_UICommandDictionary[uiName]=仿微信_cmd
        Fun.Register(uiName,'root',root)
        style = 仿微信_sty.SetupStyle()
        if isTKroot == True:
            Fun.SetTitleBar(root,titleText='仿微信',isDarkMode=False)
            Fun.CenterDlg(uiName,root,960,640)
            Fun.WindowDraggable(root,False,0,'#ffffff')
            root['background'] = '#EFEFEF'
        root.bind('<Configure>',self.Configure)
        Form_1= tkinter.Canvas(root,width = 10,height = 4)
        Form_1.pack(side=tkinter.TOP,fill=tkinter.BOTH,expand=True)
        Form_1.configure(width = 960)
        Form_1.configure(height = 640)
        Form_1.configure(bg = "#EFEFEF")
        Form_1.configure(highlightthickness = 0)
        Fun.Register(uiName,'Form_1',Form_1)
        Fun.SetUIRootSize(uiName,960,640)
        #Create the elements of root 
        Frame_2 = tkinter.Frame(Form_1)
        Fun.Register(uiName,'PyMe_Frame_2',Frame_2,'Frame_1')
        Fun.SetControlPlace(uiName,'PyMe_Frame_2',0,0,80,640,'nw',True,True)#lock
        Frame_2.configure(bg = "#434A54")
        LabelButton_8= EXUIControl.LabelButton(Frame_2)
        Fun.Register(uiName,'PyMe_LabelButton_8',LabelButton_8,'LabelButton_1')
        LabelButton_8.SetText("")
        LabelButton_8.SetBGColor("#EFEFEF")
        LabelButton_8.SetFGColor("#000000")
        LabelButton_8.SetBGImage("头像.png")
        LabelButton_8.SetBGColor_Hover("#AAAAAA")
        LabelButton_8.SetFGColor_Hover("#000000")
        LabelButton_8.SetBGColor_Click("#AAAAAA")
        LabelButton_8.SetFGColor_Click("#FF0000")
        Fun.SetControlPlace(uiName,'PyMe_LabelButton_8',10,10,60,60,'nw',True,True)#lock
        LabelButton_8.Redraw()
        LabelButton_9= EXUIControl.LabelButton(Frame_2)
        Fun.Register(uiName,'PyMe_LabelButton_9',LabelButton_9,'LabelButton_2')
        LabelButton_9.SetText("")
        LabelButton_9.SetBGColor("#EFEFEF")
        LabelButton_9.SetFGColor("#000000")
        LabelButton_9.SetBGImage("ICO_PC.png")
        LabelButton_9.SetBGColor_Hover("#AAAAAA")
        LabelButton_9.SetFGColor_Hover("#000000")
        LabelButton_9.SetBGColor_Click("#AAAAAA")
        LabelButton_9.SetFGColor_Click("#FF0000")
        Fun.SetControlPlace(uiName,'PyMe_LabelButton_9',10,80,60,60,'nw',True,True)#lock
        LabelButton_9.Redraw()
        LabelButton_9.SetCommandFunction(仿微信_cmd.LabelButton_2_onCommand,self.uiName,"LabelButton_2")
        LabelButton_10= EXUIControl.LabelButton(Frame_2)
        Fun.Register(uiName,'PyMe_LabelButton_10',LabelButton_10,'LabelButton_3')
        LabelButton_10.SetText("")
        LabelButton_10.SetBGColor("#EFEFEF")
        LabelButton_10.SetFGColor("#000000")
        LabelButton_10.SetBGImage("ICO_Team.png")
        LabelButton_10.SetBGColor_Hover("#AAAAAA")
        LabelButton_10.SetFGColor_Hover("#000000")
        LabelButton_10.SetBGColor_Click("#AAAAAA")
        LabelButton_10.SetFGColor_Click("#FF0000")
        Fun.SetControlPlace(uiName,'PyMe_LabelButton_10',10,150,60,60,'nw',True,True)#lock
        LabelButton_10.Redraw()
        LabelButton_10.SetCommandFunction(仿微信_cmd.LabelButton_3_onCommand,self.uiName,"LabelButton_3")
        LabelButton_11= EXUIControl.LabelButton(Frame_2)
        Fun.Register(uiName,'PyMe_LabelButton_11',LabelButton_11,'LabelButton_4')
        LabelButton_11.SetText("")
        LabelButton_11.SetBGColor("#EFEFEF")
        LabelButton_11.SetFGColor("#000000")
        LabelButton_11.SetBGImage("ICO_Setup.png")
        LabelButton_11.SetBGColor_Hover("#AAAAAA")
        LabelButton_11.SetFGColor_Hover("#000000")
        LabelButton_11.SetBGColor_Click("#AAAAAA")
        LabelButton_11.SetFGColor_Click("#FF0000")
        Fun.SetControlPlace(uiName,'PyMe_LabelButton_11',10,220,60,60,'nw',True,True)#lock
        LabelButton_11.Redraw()
        LabelButton_11.SetCommandFunction(仿微信_cmd.LabelButton_4_onCommand,self.uiName,"LabelButton_4")
        Frame_6 = tkinter.Frame(Form_1)
        Fun.Register(uiName,'PyMe_Frame_6',Frame_6,'Frame_2')
        Fun.SetControlPlace(uiName,'PyMe_Frame_6',80,80,250,560,'nw',True,True)#lock
        Frame_6.configure(bg = "#CCCCCC")
        Frame_7 = tkinter.Frame(Form_1)
        Fun.Register(uiName,'PyMe_Frame_7',Frame_7,'Frame_3')
        Fun.SetControlPlace(uiName,'PyMe_Frame_7',330,0,630,640,'nw',True,True)#lock
        Frame_7.configure(bg = "#CCCCCC")
        Entry_4= EXUIControl.CustomEntry(Form_1)
        Fun.Register(uiName,'PyMe_Entry_4',Entry_4,'Entry_1')
        Entry_4.SetBGColor("#CCD1D9")
        Entry_4.SetFGColor("#000000")
        Entry_4.SetTipText("搜索")
        Entry_4.SetTipFGColor("#888888")
        Entry_4.SetRelief("sunken")
        Fun.SetControlPlace(uiName,'PyMe_Entry_4',85,20,185,40,'nw',True,True)#lock
        Entry_4.bind("<Return>",Fun.EventFunction_Adaptor(仿微信_cmd.Entry_1_onReturn,uiName=uiName,widgetName="Entry_1"))
        Button_12 = tkinter.Button(Form_1,text="")
        Fun.Register(uiName,'PyMe_Button_12',Button_12,'Button_1')
        Fun.SetControlPlace(uiName,'PyMe_Button_12',280,20,40,40,'nw',True,True)
        Button_12.configure(bg = "#CCD1D9")
        仿微信_cmd.ElementBGArray[12]=Fun.LoadImageFromFile("Resources/搜索.png",None,uiName,'Button_1')
        仿微信_cmd.ElementBGArray_Resize[12] = 仿微信_cmd.ElementBGArray[12].resize((40, 40),Image.LANCZOS)
        仿微信_cmd.ElementBGArray_IM[12] = ImageTk.PhotoImage(仿微信_cmd.ElementBGArray_Resize[12])
        Button_12.configure(image = 仿微信_cmd.ElementBGArray_IM[12])
        Button_12.configure(relief = "flat")
        Button_12.configure(command=lambda:Fun.CommandFunction_Adaptor(仿微信_cmd.Button_1_onCommand,uiName,"Button_1"))
        #Inital all element's Data 
        Fun.InitElementData(uiName)
        #Call Form_1's OnLoad Function
        Fun.RunForm1_CallBack(uiName,"Load",仿微信_cmd.Form_1_onLoad)
        #Add Some Logic Code Here: (Keep This Line of comments)



        #Exit Application: (Keep This Line of comments)
        if self.isTKroot == True and Fun.GetElement(self.uiName,"root"):
            self.root.protocol('WM_DELETE_WINDOW', self.Exit)
            
    def GetRootSize(self):
        return Fun.GetUIRootSize(self.uiName)
    def GetAllElement(self):
        return Fun.G_UIElementDictionary[self.uiName]
    def Escape(self,event):
        if Fun.AskBox('提示','确定退出程序？') == True:
            self.Exit()
    def Exit(self):
        if self.isTKroot == True:
            Fun.DestroyUI(self.uiName)

    def Configure(self,event):
        Form_1 = Fun.GetElement(self.uiName,'Form_1')
        if Form_1 == event.widget:
            Fun.ReDrawCanvasRecord(self.uiName)
        if self.root == event.widget:
            Fun.ResizeRoot(self.uiName,self.root,event)
            Fun.ResizeAllChart(self.uiName)
            uiName = self.uiName
            pass
        Fun.ActiveElement(self.uiName,event.widget)
#Create the root of Kinter 
if  __name__ == '__main__':
    Fun.RunApplication(仿微信)
